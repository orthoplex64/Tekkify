Flaxbeards-Steam-Power Localisation project
======================
If you are native to any language not listed here, fork this repo and work on this branch to localize the mod for your country.<br>
<b>You may create new translations or work to improve existing ones. Please add the contributions to a changelog.<br>The license of those files are the same of the mod.<b/>
Current translations are: 
<ul>
<li>English - USA</li>
<li>Brazilian - Portuguese</li>
<li>Chinese - China</li>
<li>Tradtional Chinese - China</li>
<li>German - Germany</li>
<li>Russia - Russian</li>
</ul>
<br>
<b>
Why should I contribute?
You can give people of your country that don't understand English very well the ability to play and understand the mod more fully.<br>
Be sure to credit yourself down here:
<ul>
<li>The original mod team: en_US</li>
<li>matheusxaviersi: pt_BR</li>
<li>Mrkwtkr: zh_CN</li>
<li>Gholuk: de_DE</li>
<li>Vexatos: de_DE</li>
<li>mymagadsl: zh_TW</li>
<li>Adaptivity: ru_RU</li>
</ul></b>
